Agri-PIDNet-S Representative Minimal Dataset
=============================================

Overview
--------
This package contains six representative image-label pairs selected from the
complete dataset of 709 independently collected and pixel-wise annotated images
used in the Agri-PIDNet-S study. It is intended to allow editors and readers to
inspect the image format, semantic classes, and annotation quality without
downloading the complete dataset.

Important limitation
--------------------
This representative subset is not sufficient to reproduce the quantitative
results reported in the manuscript. It must not be treated as the complete
training, validation, or test dataset. The full dataset that supports the
findings of the study is available from the corresponding author upon
reasonable request.

Data source
-----------
The images were collected in real seedling-stage cotton fields at Huaxing Farm,
Changji Hui Autonomous Prefecture, Xinjiang Uygur Autonomous Region, China,
from May to June 2025.

Package contents
----------------
images/           Original RGB images in PNG format.
labels/           Single-channel indexed semantic labels in PNG format.
class_mapping.csv Class identifiers, names, definitions, and preview colors.
manifest.csv      Sample provenance, dimensions, class-pixel counts, and notes.

Label encoding
--------------
0  Background  Sky, distant scenery, and areas outside the other classes.
1  Crop row   Cotton plants and continuous vegetation along the planting direction.
2  Furrow     Bare-soil furrows and potential passages between adjacent crop rows.
3  Obstacle   People, field facilities, and other objects that may impede vehicles.

The files in labels/ contain integer class IDs and should be used for analysis.

Selected scenes
---------------
00288  Irrigation pipe and local field interference.
00621  Crop-row and furrow continuity with small obstacle structures.
00655  Oblique crop rows, plastic mulch, and small distant obstacles.
00963  Long-range perspective convergence of crop rows and furrows.
01128  A person and irrigation or monitoring facilities.
01597  A person obstacle and perspective row structure.

Access and contact
------------------
The full dataset that supports the findings of this study is available from
the corresponding author upon reasonable request.

Corresponding author: Yanhong Chen
Email: cyh@xjau.edu.cn

This representative subset is provided for editorial assessment and research
verification. Please contact the corresponding author regarding reuse or
redistribution.
